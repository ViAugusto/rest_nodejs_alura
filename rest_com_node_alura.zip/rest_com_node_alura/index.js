const customExpress = require('./config/customExpress');
const connection = require('./infra/connection');
const Tabelas = require('./infra/tables');


connection.connect(erro => {
    if(erro){
        console.log(erro);
    }
    else{
        console.log('FOI AEEW');

        Tabelas.init(connection);

        const app = customExpress();
        app.listen(3000, () => console.log('Tá rodando aaew!'));
    }

});

