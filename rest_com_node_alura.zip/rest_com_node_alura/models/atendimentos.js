const moment = require('moment');
const connection = require('../infra/connection');

class Atendimento {

    adiciona(atendimento, res) {
        // Formatação de datas.
        const dataCriacao = moment().format('YYYY-MM-DD HH:MM:SS');
        const data = moment(atendimento.data, 'DD/MM/YYYY').format('YYYY-MM-DD HH:MM:SS');
        //Validação de datas e de cliente.
        const validarData = moment(data).isSameOrAfter(dataCriacao);
        const validarCliente = atendimento.cliente.lenght >= 5

        const validacoes = [
            {
                nome: 'data',
                valida: validarData,
                mensagem: 'Data deve ser maior ou igual a data atual.'
            },
            {
                nome: 'cliente',
                valido: validarCliente,
                mensagem: 'Cliente deve ter pelo menos cinco caracteres.'
            }
        ]

        const erros = validacoes.filter(campo => !campo.valido);
        const existemErros = erros.lenght;

        if (existemErros == true) {
            res.status(400).json(erros);
        }
        else {
            const atendimentoDatado = { ...atendimento, data, dataCriacao };
            const sql = 'INSERT INTO atendimentos(cliente, pet, servico, status, observacoes, data, dataCriacao) VALUES (?, ?, ?, ?, ?, ?, ?);'

            connection.query(sql, [atendimentoDatado.cliente, atendimentoDatado.pet, atendimentoDatado.servico, atendimentoDatado.status, atendimentoDatado.observacoes, atendimentoDatado.data, atendimentoDatado.dataCriacao], (erro, resultados) => {
                if (erro) {
                    res.status(400).json(erro);
                }
                else {
                    res.status(201).json(resultados);
                }
            });
        }


    }

    lista(res) {
        const sql = 'SELECT * FROM atendimentos'

        connection.query(sql, function (erro, resultados) {
            if (erro) {
                res.status(400).json(erro);
            }
            else {
                res.status(200).json(resultados);
            }
        })

    }
}


module.exports = new Atendimento;