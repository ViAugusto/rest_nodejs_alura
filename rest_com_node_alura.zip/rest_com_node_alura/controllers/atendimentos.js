const Atendimento = require('../models/atendimentos')

module.exports = app => {
    app.get('/atendimentos', function(req, res){
        Atendimento.lista(res);
    });

    app.post('/atendimentos', (req, res) => {
        const atendimento = req.body;
        console.log(req.body);


        Atendimento.adiciona(atendimento, res);
    }
    )
}